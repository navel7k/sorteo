export class CreateSorteoDto {}
