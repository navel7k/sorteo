import { SorteoEntity } from './sorteo.entity';

describe('SorteoEntity', () => {
  it('should be defined', () => {
    expect(new SorteoEntity()).toBeDefined();
  });
});
