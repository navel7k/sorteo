import { EnteEntity } from './ente.entity';

describe('EnteEntity', () => {
  it('should be defined', () => {
    expect(new EnteEntity()).toBeDefined();
  });
});
