import { AreaorganizacionalEntity } from './areaorganizacional.entity';

describe('AreaorganizacionalEntity', () => {
  it('should be defined', () => {
    expect(new AreaorganizacionalEntity()).toBeDefined();
  });
});
