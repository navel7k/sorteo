import { OficinaEntity } from './oficina.entity';

describe('OficinaEntity', () => {
  it('should be defined', () => {
    expect(new OficinaEntity()).toBeDefined();
  });
});
